# Slot Machine Tracker MVP

Starter repository for a slot machine tracking web app.

Tech stack:
Frontend: Next.js + React + Tailwind
Backend: FastAPI (Python)
Database: Supabase / PostgreSQL

Steps:
1. Deploy frontend on Vercel
2. Deploy backend on Railway/Render
3. Connect database credentials in .env