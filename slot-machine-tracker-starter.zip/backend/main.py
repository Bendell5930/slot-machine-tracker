from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def root():
    return {"message": "Slot Machine Tracker API running"}