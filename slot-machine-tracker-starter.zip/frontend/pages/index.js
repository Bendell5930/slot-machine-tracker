import MachineCard from "../components/MachineCard";

export default function Dashboard() {
  const machines = [
    { id: 1, name: "Dragon Link #24", heat: 85 },
    { id: 2, name: "Lightning Link #11", heat: 55 },
    { id: 3, name: "Buffalo Gold #6", heat: 20 }
  ];

  return (
    <div style={{padding:20}}>
      <h1>Machine Heat Map</h1>
      {machines.map(m => (
        <MachineCard key={m.id} machine={m} />
      ))}
    </div>
  );
}