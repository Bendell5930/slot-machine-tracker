import HeatMeter from "./HeatMeter";

export default function MachineCard({ machine }) {
  return (
    <div style={{border:"1px solid #ccc",padding:10,marginBottom:10}}>
      <h3>{machine.name}</h3>
      <HeatMeter heat={machine.heat} />
    </div>
  );
}