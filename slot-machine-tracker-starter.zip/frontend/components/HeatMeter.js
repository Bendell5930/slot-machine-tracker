export default function HeatMeter({ heat }) {
  const barStyle = {
    width: heat + "%",
    height: "10px",
    backgroundColor: heat > 70 ? "red" : heat > 40 ? "orange" : "blue"
  };

  return (
    <div style={{background:"#eee",width:"100%",height:"10px"}}>
      <div style={barStyle}></div>
    </div>
  );
}